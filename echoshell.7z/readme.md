# 🧠 EchoShell · Terminal Legend

EchoShell is a modular and immersive terminal built in Python to deliver a stylized, customizable, and extensible interface. Every command is a module. Every launch is a performance.

---

## Requirements

- Python 3.11 (Minimum)  
- A little bit of coding knowledge (not required, but if you want to create your own commands, trust me—you’ll need it)

---

## 🎬 Getting Started

Run EchoShell with:

```bash
python main.py
```

```bash
Or double-click the file main.py
```

You’ll see an animated intro, an ASCII logo, and the system ready to receive your commands.

---

## 🔥 Core Commands Available

Type `help` in EchoShell to display all available commands. (Custom commands are automatically detected when you make one and you need to just add hidden = true/false to be shown or not when you do help and you can do DESCRIPTION too if in the help you want to add a description about that command   SEE LINE 95 )

### 📂 `launch`

Launch a file or app from the `apps` folder.

- `launch test.txt` → opens the text file  
- `launch MonApp` → launches the `.exe` inside `apps/MonApp/`  
- `launch list` → shows all available files and folders

### ✅ `todo`

Manage your task list.

- `todo add "Make coffee"` → adds a task  
- `todo list` → displays all tasks  
- `todo remove 1` → removes task #1

### 🔐 `encrypt` / `decrypt`

Encrypt or decrypt a file using a simple XOR algorithm.

- `encrypt secret.txt` → encrypts the file  
- `decrypt secret.txt` → decrypts it

### 🧠 `help`

- `help` → shows all available commands  
- `help command` → shows detailed info about the command

### 🌐 `ask`

Searches the web for your question and displays top results.

- `ask "how does XOR encryption work"` → shows summarized web answers

### 🧼 `cls`

Clears the screen and reprints the EchoShell boot sequence and logo.

---

## 📁 The `apps/` Folder

EchoShell uses the `apps/` folder to launch files or applications.

You can place:

- `.exe`, `.txt` files (More formats will be supported later)  
- Folders containing a `.exe`

Examples:

```
apps/
├── test.txt
├── tool.exe
└── MonApp/
    └── MonApp.exe
```

---

## 🛠️ Adding a Command (Optional)

You don’t need to code to use EchoShell.  
But if you want to create your own commands, it’s possible.

Create a file inside `commands/`:

```python
# commandes/my_command.py

DESCRIPTION = "Description of your command."
HIDDEN = False

def run(args):
    print("Command executed with:", args)
```

It will be automatically recognized by EchoShell.  
If you want it hidden from `help`, set `HIDDEN = True`.

---

## 🧩 Example Usage

```bash
EchoShell > todo add "Finish EchoShell"
EchoShell > todo list
EchoShell > encrypt "secret.txt"
EchoShell > decrypt "secret.txt"
EchoShell > launch list
EchoShell > launch test.txt
EchoShell > ask "who invented Python"
EchoShell > cls
EchoShell > help
EchoShell > help encrypt
```

---

## 🌐 Full Documentation

A detailed wiki will soon be available at:

**https://echo-shell.vercel.app**

There you’ll find:

- Tutorials  
- Advanced commands  
- Customization  
- Extensions

---