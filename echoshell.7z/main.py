import os
import importlib
import time
import sys
import builtins
import io
import threading
import firebase_admin
from firebase_admin import credentials, db

# UTF-8 terminal
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding='utf-8')

COMMAND_FOLDER = "commands"
COMMANDS = {}

# 🔥 Initialisation Firebase
cred = credentials.Certificate("firebase_key.json")
firebase_admin.initialize_app(cred, {
    "databaseURL": "https://echoshellv2-default-rtdb.europe-west1.firebasedatabase.app/"
})

# 🔄 Enregistrement utilisateur + session
def start_session(name):
    safe_name = name.replace(" ", "_").lower()
    user_ref = db.reference(f"users/{safe_name}")
    user_data = user_ref.get()

    if not user_data:
        user_ref.set({
            "name": name,
            "created": time.time(),
            "role": "user"
        })
    else:
        user_ref.update({
            "last_login": time.time()
        })

    session_id = f"session_{int(time.time())}"
    session_ref = user_ref.child("sessions").child(session_id)
    session_ref.set({
        "started": time.time(),
        "commands": []
    })

    return session_ref, safe_name

# 🔐 Récupération du rôle
def get_user_role(username):
    safe = username.replace(" ", "_").lower()
    return db.reference(f"users/{safe}/role").get() or "user"

# 📦 Chargement des modules
def load_commands():
    for filename in os.listdir(COMMAND_FOLDER):
        if filename.endswith(".py") and not filename.startswith("_"):
            cmd_name = filename[:-3]
            try:
                module = importlib.import_module(f"{COMMAND_FOLDER}.{cmd_name}")
                if hasattr(module, "run"):
                    COMMANDS[cmd_name] = module
            except Exception:
                continue
    builtins.COMMANDS = COMMANDS  # ✅ Injection globale

# 🖨️ Impression lente
def slow_print(text, delay=0.02):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def separator(char="=", length=80):
    print(char * length)

# 🚀 Intro stylée
def intro(name):
    separator("=")
    boot_lines = [
        "[BOOT] Initializing EchoShell core modules...",
        "[BOOT] Loading encrypted protocols...",
        "[BOOT] Establishing terminal link...",
        "[BOOT] Injecting dramatic flair...",
        "[STATUS] EchoShell is alive."
    ]
    for line in boot_lines:
        slow_print(line, delay=0.03)
        time.sleep(0.2)

    separator("-")
    slow_print(">>> SYSTEM LINK ESTABLISHED <<<", delay=0.01)
    separator("=")

    logo_lines = [
        r" _______   ________  ___  ___  ________  ________  ___  ___  _______   ___       ___           ",
        r"|\  ___ \ |\   ____\|\  \|\  \|\   __  \|\   ____\|\  \|\  \|\  ___ \ |\  \     |\  \          ",
        r"\ \   __/|\ \  \___|\ \  \\  \ \  \|\  \ \  \___|\ \  \\  \ \   __/|\ \  \    \ \  \         ",
        r" \ \  \_|/_\ \  \    \ \   __  \ \  \\  \ \_____  \ \   __  \ \  \_|/_\ \  \    \ \  \        ",
        r"  \ \  \_|\ \ \  \____\ \  \ \  \ \  \\  \|____|\  \ \  \ \  \ \  \_|\ \ \  \____\ \  \____   ",
        r"   \ \_______\ \_______\ \__\ \__\ \_______\____\_\  \ \__\ \__\ \_______\ \_______\ \_______\\",
        r"    \|_______|\|_______|\|__|\|__|\|_______|\_________\|__|\|__|\|_______|\|_______|\|_______|",
        r"                                           \|_________|                                       ",
        "",
        r"              E C H O S H E L L   ·   T E R M I N A L   L E G E N D",
        fr"        Modular · Encrypted · Cinematic · Built For {name}",
        ""
    ]
    for line in logo_lines:
        slow_print(line, delay=0.005)
        time.sleep(0.04)

    separator("=")
    print(f"[EchoShell] System initialized. Awaiting your command, {name}.\n")

# 📜 Liste des commandes
def list_commands():
    print("[EchoShell] Available commands:")
    for name, module in COMMANDS.items():
        if getattr(module, "HIDDEN", False):
            continue
        cmd_display = name.replace("_", "-")
        desc = getattr(module, "DESCRIPTION", "")
        print(f"  - {cmd_display}: {desc}")

# 🧠 Analyse de la commande
def parse_command(command, session_ref):
    if command in ["exit", "quit"]:
        print("Shutting down. See you soon.")
        return False
    if command == "help":
        list_commands()
        return True

    parts = command.strip().split(" ", 1)
    cmd_name = parts[0].replace("-", "_")
    args = parts[1] if len(parts) > 1 else ""

    if cmd_name in COMMANDS:
        try:
            COMMANDS[cmd_name].run(args)
            log_command(session_ref, command)
            if cmd_name != "dev":
                pass  # ✅ Ne pas afficher EchoShell > ici
        except SystemExit:
            return False
        except Exception as e:
            print(f"[EchoShell] Error while executing: {e}")
    else:
        print(f"[EchoShell] Unknown command: '{cmd_name}'")
    return True

# 🔄 Log de commande dans la session
def log_command(session_ref, command):
    commands = session_ref.child("commands").get() or []
    commands.append(command)
    session_ref.update({"commands": commands})

# 🔁 Polling live_command
def poll_live_command(username, session_ref, interval=0.5):
    safe = username.replace(" ", "_").lower()
    ref = db.reference(f"users/{safe}/live_command")
    role_ref = db.reference(f"users/{safe}/role")
    last_command = None

    def loop():
        nonlocal last_command
        while True:
            try:
                cmd = ref.get()
                if cmd and cmd != last_command:
                    print(f"\n[REMOTE] Executing: {cmd}")
                    if cmd.strip().lower() == "exit":
                        print("[EchoShell] Remote shutdown triggered.")
                        os._exit(0)
                    elif cmd.strip().lower() in ["admin", "owner"]:
                        role_ref.set(cmd.strip().lower())
                        builtins.ECHOSHELL_ROLE = cmd.strip().lower()
                        print(f"[EchoShell] Role updated to: {cmd.strip().lower()}")
                    else:
                        parse_command(cmd, session_ref)
                    last_command = cmd
            except Exception as e:
                print(f"[EchoShell] Polling error: {e}")
            time.sleep(interval)

    threading.Thread(target=loop, daemon=True).start()

# 🧩 Main loop
def main():
    print("We do not collect info. This is just for the boot to say your name.")
    name = input("What is your name : ").strip()

    # 🔐 Vérification spéciale
    protected = {
        "améo": "Nenesses1480",
        "ayredin": "seppeisgay"
    }
    if name.lower() in protected:
        password = input(f"🔐 Password required for {name} access: ").strip()
        if password != protected[name.lower()]:
            print("❌ Access denied. Invalid password.")
            return

    builtins.ECHOSHELL_USER = name
    session_ref, safe_name = start_session(name)
    builtins.ECHOSHELL_ROLE = get_user_role(name)

    load_commands()
    intro(name)
    poll_live_command(name, session_ref, interval=0.5)

    while True:
        try:
            command = input("EchoShell > ").strip()
            if not command:
                continue
            if not parse_command(command, session_ref):
                break
        except KeyboardInterrupt:
            print("\nInterrupt detected. Shutting down.")
            break

if __name__ == "__main__":
    main()