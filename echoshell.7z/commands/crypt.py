import os

DESCRIPTION = "Encrypts a file from the 'crypting' folder using XOR."
HIDDEN = False

def xor_encrypt(data, key=42):
    return bytes([b ^ key for b in data])

def run(args):
    if not args:
        print("[ENCRYPT] Usage: encrypt <filename>")
        return

    filename = args.strip('"')
    path = os.path.join("crypting", filename)

    if not os.path.isfile(path):
        print(f"[ENCRYPT] File not found in 'crypting': {filename}")
        return

    try:
        with open(path, "rb") as f:
            data = f.read()
        encrypted = xor_encrypt(data)
        with open(path, "wb") as f:
            f.write(encrypted)
        print(f"[ENCRYPT] File encrypted: {filename}")
    except Exception as e:
        print(f"[ENCRYPT] Error: {e}")