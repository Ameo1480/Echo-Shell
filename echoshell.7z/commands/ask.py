from ddgs import DDGS

DESCRIPTION = "Searches the web for your question and displays top results."
HIDDEN = False

def run(args):
    if not args:
        print("[ASK] Usage: ask \"your question here\"")
        return

    query = args.strip('"')
    print(f"[ASK] Searching DuckDuckGo for: {query}\n")

    try:
        with DDGS() as ddgs:
            results = ddgs.text(query, max_results=3)
            if not results:
                print("[ASK] No results found.")
                return

            for i, result in enumerate(results, 1):
                title = result.get("title", "No title")
                snippet = result.get("body", "No description")
                link = result.get("href", "No link")

                print(f"[{i}] {title}")
                print(f"    {snippet}")
                print(f"    🔗 {link}\n")

    except Exception as e:
        print(f"[ASK] Error while searching: {e}")