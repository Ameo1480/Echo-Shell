import os
import subprocess

HIDDEN = False
DESCRIPTION = "Launches a file or app from the 'apps' folder. Supports .exe, .txt, or folders containing an .exe. Use 'launch list' to view available items."

APPS_DIR = "apps"

def run(args):
    if not args:
        print("[LAUNCHER] Usage: 'launch <name>' or 'launch list'")
        return

    if args == "list":
        if not os.path.exists(APPS_DIR):
            print("[LAUNCHER] 'apps' folder not found.")
            return

        items = os.listdir(APPS_DIR)
        if not items:
            print("[LAUNCHER] No apps found.")
            return

        print("[LAUNCHER] Available apps:")
        for item in items:
            path = os.path.join(APPS_DIR, item)
            if os.path.isdir(path):
                print(f"  [folder] {item}")
            else:
                print(f"  [file]   {item}")
        return

    name = args.strip('"')
    path = os.path.join(APPS_DIR, name)

    # Fichier direct
    if os.path.isfile(path):
        try:
            os.startfile(path)
            print(f"[LAUNCHER] Launched: {name}")
        except Exception as e:
            print(f"[LAUNCHER] Failed to launch file: {e}")
        return

    # Dossier contenant un .exe
    if os.path.isdir(path):
        for file in os.listdir(path):
            if file.lower().endswith(".exe"):
                exe_path = os.path.join(path, file)
                try:
                    os.startfile(exe_path)
                    print(f"[LAUNCHER] Launched: {file} from folder '{name}'")
                except Exception as e:
                    print(f"[LAUNCHER] Failed to launch executable: {e}")
                return
        print(f"[LAUNCHER] No .exe found in folder '{name}'")
        return

    print(f"[LAUNCHER] '{name}' not found in apps folder.")