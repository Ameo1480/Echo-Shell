import json
import os

HIDDEN = False
DESCRIPTION = "Add, list, remove, or show details for names."

NAMES_FILE = "data/1d.json"

def load_names():
    if not os.path.exists(NAMES_FILE):
        return []
    with open(NAMES_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_names(names):
    with open(NAMES_FILE, "w", encoding="utf-8") as f:
        json.dump(names, f, indent=2, ensure_ascii=False)

def run(args):
    names = load_names()

    if args.startswith("add "):
        parts = args[4:].strip().split(" ", 1)
        if len(parts) != 2:
            print("[NAME] Usage: name add <ID> \"Full Name\"")
            return
        id_str = parts[0].strip()
        full_name = parts[1].strip().strip('"')
        if any(entry.get("id") == id_str for entry in names):
            print(f"[NAME] ID {id_str} already exists.")
            return
        new_entry = {
            "id": id_str,
            "name": full_name,
            "bio": "No bio provided.",
            "lang": "en",
            "birthday": "Unknown"
        }
        names.append(new_entry)
        save_names(names)
        print(f"[NAME] Added: \"{full_name}\" with ID {id_str}")

    elif args == "list":
        if not names:
            print("[NAME] No names found.")
            return
        print("[NAME] Current names:")
        for entry in names:
            print(f"  {entry['id']}. {entry['name']}")

    elif args.startswith("remove "):
        target_id = args[7:].strip()
        updated = [entry for entry in names if entry.get("id") != target_id]
        if len(updated) == len(names):
            print(f"[NAME] No name found with ID {target_id}.")
        else:
            save_names(updated)
            print(f"[NAME] Removed name with ID {target_id}.")

    elif args.startswith("detail "):
        target_id = args[7:].strip()
        for entry in names:
            if entry.get("id") == target_id:
                print(f"\n[DETAILS FOR: {target_id}]")
                print(f"Full Name : {entry.get('name')}")
                print(f"Language  : {entry.get('lang')}")
                print(f"Bio       : {entry.get('bio')}")
                print(f"Birthday  : {entry.get('birthday')}\n")
                return
        print(f"[NAME] No details found for ID {target_id}.")

    else:
        print("[NAME] Usage:")
        print("  - name add <ID> \"Full Name\"")
        print("  - name list")
        print("  - name remove <ID>")
        print("  - name detail <ID>")