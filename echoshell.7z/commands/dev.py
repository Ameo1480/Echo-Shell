DESCRIPTION = "Opens DevShell for owners only"
HIDDEN = True

def run(args):
    import builtins
    import platform
    import time
    import os
    import sys
    from firebase_admin import db

    role = getattr(builtins, "ECHOSHELL_ROLE", "user")
    if role != "owner":
        print("[EchoShell] Access denied. DevShell is reserved for owner.")
        return

    COMMANDS = builtins.COMMANDS  # accès aux modules EchoShell

    def clear_screen():
        os.system("cls" if os.name == "nt" else "clear")
        print("[DEV ACCESS GRANTED]")
        print("Launching DevShell...\n")

    def show_help():
        print("🛠️ DevShell Commands:")
        print("  - cls       : Clear screen and relaunch DevShell intro")
        print("  - help      : Show this help menu")
        print("  - db list   : List all usernames in Firebase")
        print("  - db <name> : Dump full data for user <name>")
        print("  - exit      : Exit DevShell")
        print("  - [any EchoShell command]")

    def format_sessions(sessions):
        output = []
        for sid, data in sessions.items():
            started = int(data.get("started", 0))
            commands = data.get("commands", [])
            output.append(f"🧵 {sid}")
            output.append(f"   🕒 Started: {started}")
            output.append(f"   📜 Commands: {', '.join(commands) if commands else 'None'}")
        return "\n".join(output)

    def devshell():
        clear_screen()
        while True:
            try:
                cmd = input("DevShell > ").strip()
                if not cmd:
                    continue

                if cmd in ["exit", "quit"]:
                    print("Exiting DevShell.")
                    break

                if cmd == "cls":
                    clear_screen()
                    continue

                if cmd == "help":
                    show_help()
                    continue

                if cmd == "db list":
                    users = db.reference("users").get()
                    if not users:
                        print("No users found.")
                        continue
                    print("🧑‍💻 Users:")
                    for name in users:
                        print(f"  - {name}")
                    continue

                if cmd.startswith("db "):
                    target = cmd[3:].strip()
                    if not target:
                        print("[DevShell] Please specify a username.")
                        continue
                    user_data = db.reference(f"users/{target}").get()
                    if not user_data:
                        print(f"[DevShell] No data found for user '{target}'")
                        continue
                    print(f"\n📂 Data for '{target}':")
                    for key, value in user_data.items():
                        if key == "sessions":
                            print("  🧩 sessions:")
                            print(format_sessions(value))
                        else:
                            print(f"  🧩 {key}: {value}")
                    print()
                    continue

                # 🔁 EchoShell command support
                parts = cmd.split(" ", 1)
                cmd_name = parts[0].replace("-", "_")
                args = parts[1] if len(parts) > 1 else ""

                if cmd_name in COMMANDS:
                    try:
                        COMMANDS[cmd_name].run(args)
                    except Exception as e:
                        print(f"[DevShell] Error while executing '{cmd_name}': {e}")
                else:
                    print(f"[DevShell] Unknown command: '{cmd}'")

            except KeyboardInterrupt:
                print("\nDevShell interrupted.")
                break
            except Exception as e:
                print(f"[DevShell] Error: {e}")

    devshell()
    sys.exit(0)  # ✅ Quitte EchoShell proprement après DevShell