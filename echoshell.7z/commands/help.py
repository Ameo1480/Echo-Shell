import os
import importlib

HIDDEN = False
DESCRIPTION = "Displays all available commands or details about a specific one."

COMMAND_FOLDER = "commandes"

def run(args):
    args = args.strip('"')
    if not args:
        print("[HELP] Available commands:")
        for filename in os.listdir(COMMAND_FOLDER):
            if filename.endswith(".py") and not filename.startswith("_"):
                cmd_name = filename[:-3].replace("_", "-")
                try:
                    module = importlib.import_module(f"{COMMAND_FOLDER}.{filename[:-3]}")
                    if getattr(module, "HIDDEN", False):
                        continue
                    desc = getattr(module, "DESCRIPTION", "No description available.")
                    print(f"  - {cmd_name}: {desc}")
                except Exception:
                    continue
    else:
        cmd_name = args.replace("-", "_")
        try:
            module = importlib.import_module(f"{COMMAND_FOLDER}.{cmd_name}")
            if getattr(module, "HIDDEN", False):
                print(f"[HELP] '{args}' is a hidden command.")
                return
            desc = getattr(module, "DESCRIPTION", "No description available.")
            print(f"[HELP] {args}: {desc}")
        except ModuleNotFoundError:
            print(f"[HELP] Command '{args}' not found.")