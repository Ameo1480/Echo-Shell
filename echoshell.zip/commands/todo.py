import json
import os

HIDDEN = False
DESCRIPTION = "Add, list, or remove tasks from your todo list."

TASKS_FILE = "data/tasks.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return []
    with open(TASKS_FILE, "r") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return []

def save_tasks(tasks):
    with open(TASKS_FILE, "w") as f:
        json.dump(tasks, f, indent=2)

def run(args):
    if args.startswith("add "):
        task = args[4:].strip('"')
        tasks = load_tasks()
        tasks.append({"task": task})
        save_tasks(tasks)
        print(f"[TODO] Task added: \"{task}\"")

    elif args == "list":
        tasks = load_tasks()
        if not tasks:
            print("[TODO] No tasks found.")
            return
        print("[TODO] Current tasks:")
        for i, t in enumerate(tasks, 1):
            print(f"  {i}. {t['task']}")

    elif args.startswith("remove "):
        try:
            index = int(args[7:].strip()) - 1
            tasks = load_tasks()
            if 0 <= index < len(tasks):
                removed = tasks.pop(index)
                save_tasks(tasks)
                print(f"[TODO] Removed task: \"{removed['task']}\"")
            else:
                print("[TODO] Invalid task number.")
        except ValueError:
            print("[TODO] Usage: 'todo remove <task number>'")

    else:
        print("[TODO] Usage:")
        print("  - todo add \"task\"")
        print("  - todo list")
        print("  - todo remove <task number>")