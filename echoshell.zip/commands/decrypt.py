import os

DESCRIPTION = "Decrypts a file from the 'crypting' folder using XOR."
HIDDEN = False

def xor_decrypt(data, key=42):
    return bytes([b ^ key for b in data])

def run(args):
    if not args:
        print("[DECRYPT] Usage: decrypt <filename>")
        return

    filename = args.strip('"')
    path = os.path.join("crypting", filename)

    if not os.path.isfile(path):
        print(f"[DECRYPT] File not found in 'crypting': {filename}")
        return

    try:
        with open(path, "rb") as f:
            data = f.read()
        decrypted = xor_decrypt(data)
        with open(path, "wb") as f:
            f.write(decrypted)
        print(f"[DECRYPT] File decrypted: {filename}")
    except Exception as e:
        print(f"[DECRYPT] Error: {e}")