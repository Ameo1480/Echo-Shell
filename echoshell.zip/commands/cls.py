import os
import builtins

DESCRIPTION = "Clears the screen and reprints the EchoShell boot with your name."
HIDDEN = False

def run(args):
    os.system("cls" if os.name == "nt" else "clear")

    name = getattr(builtins, "ECHOSHELL_USER", "User")

    print("=" * 80)
    print("[BOOT] Initializing EchoShell core modules...")
    print("[BOOT] Loading encrypted protocols...")
    print("[BOOT] Establishing terminal link...")
    print("[BOOT] Injecting dramatic flair...")
    print("[STATUS] EchoShell is alive.")
    print("-" * 80)
    print(">>> SYSTEM LINK ESTABLISHED <<<")
    print("=" * 80)

    print(r" _______   ________  ___  ___  ________  ________  ___  ___  _______   ___       ___           ")
    print(r"|\  ___ \ |\   ____\|\  \|\  \|\   __  \|\   ____\|\  \|\  \|\  ___ \ |\  \     |\  \          ")
    print(r"\ \   __/|\ \  \___|\ \  \\  \ \  \|\  \ \  \___|\ \  \\  \ \   __/|\ \  \    \ \  \         ")
    print(r" \ \  \_|/_\ \  \    \ \   __  \ \  \\  \ \_____  \ \   __  \ \  \_|/_\ \  \    \ \  \        ")
    print(r"  \ \  \_|\ \ \  \____\ \  \ \  \ \  \\  \|____|\  \ \  \ \  \ \  \_|\ \ \  \____\ \  \____   ")
    print(r"   \ \_______\ \_______\ \__\ \__\ \_______\____\_\  \ \__\ \__\ \_______\ \_______\ \_______\\")
    print(r"    \|_______|\|_______|\|__|\|__|\|_______|\_________\|__|\|__|\|_______|\|_______|\|_______|")
    print(r"                                           \|_________|                                       ")
    print()
    print(r"              E C H O S H E L L   ·   T E R M I N A L   L E G E N D")
    print(f"        Modular · Encrypted · Cinematic · Built For {name}")
    print("=" * 80)
    print(f"[EchoShell] System initialized. Awaiting your command, {name}.\n")