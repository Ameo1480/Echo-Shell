import os
import importlib
import time
import sys
import builtins

COMMAND_FOLDER = "commands"
COMMANDS = {}

# Chargement des modules disponibles
def load_commands():
    for filename in os.listdir(COMMAND_FOLDER):
        if filename.endswith(".py") and not filename.startswith("_"):
            cmd_name = filename[:-3]
            try:
                module = importlib.import_module(f"{COMMAND_FOLDER}.{cmd_name}")
                if hasattr(module, "run"):
                    COMMANDS[cmd_name] = module
            except Exception:
                continue

def slow_print(text, delay=0.02):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def separator(char="=", length=80):
    print(char * length)

print("We do not collect info this is just for the boot to say your name.")
name = input("What is your name : ")

builtins.ECHOSHELL_USER = name

def intro():
    separator("=")
    boot_lines = [
        "[BOOT] Initializing EchoShell core modules...",
        "[BOOT] Loading encrypted protocols...",
        "[BOOT] Establishing terminal link...",
        "[BOOT] Injecting dramatic flair...",
        "[STATUS] EchoShell is alive."
    ]
    for line in boot_lines:
        slow_print(line, delay=0.03)
        time.sleep(0.2)

    separator("-")
    slow_print(">>> SYSTEM LINK ESTABLISHED <<<", delay=0.01)
    separator("=")

    logo_lines = [
        r" _______   ________  ___  ___  ________  ________  ___  ___  _______   ___       ___           ",
        r"|\  ___ \ |\   ____\|\  \|\  \|\   __  \|\   ____\|\  \|\  \|\  ___ \ |\  \     |\  \          ",
        r"\ \   __/|\ \  \___|\ \  \\  \ \  \|\  \ \  \___|\ \  \\  \ \   __/|\ \  \    \ \  \         ",
        r" \ \  \_|/_\ \  \    \ \   __  \ \  \\  \ \_____  \ \   __  \ \  \_|/_\ \  \    \ \  \        ",
        r"  \ \  \_|\ \ \  \____\ \  \ \  \ \  \\  \|____|\  \ \  \ \  \ \  \_|\ \ \  \____\ \  \____   ",
        r"   \ \_______\ \_______\ \__\ \__\ \_______\____\_\  \ \__\ \__\ \_______\ \_______\ \_______\\",
        r"    \|_______|\|_______|\|__|\|__|\|_______|\_________\|__|\|__|\|_______|\|_______|\|_______|",
        r"                                           \|_________|                                       ",
        "",
        r"              E C H O S H E L L   ·   T E R M I N A L   L E G E N D",
        fr"        Modular · Encrypted · Cinematic · Built For {name}",
        ""
    ]
    for line in logo_lines:
        slow_print(line, delay=0.005)
        time.sleep(0.04)

    separator("=")
    print(f"[EchoShell] System initialized. Awaiting your command, {name}.\n")

def list_commands():
    print("[EchoShell] Available commands:")
    for name, module in COMMANDS.items():
        if getattr(module, "HIDDEN", False):
            continue
        cmd_display = name.replace("_", "-")
        desc = getattr(module, "DESCRIPTION", "")
        print(f"  - {cmd_display}: {desc}")

def parse_command(command):
    if command in ["exit", "quit"]:
        print("Shutting down. See you soon.")
        return False
    if command == "help":
        list_commands()
        return True

    parts = command.strip().split(" ", 1)
    cmd_name = parts[0].replace("-", "_")
    args = parts[1] if len(parts) > 1 else ""

    if cmd_name in COMMANDS:
        try:
            COMMANDS[cmd_name].run(args)
        except Exception as e:
            print(f"[EchoShell] Error while executing: {e}")
    else:
        print(f"[EchoShell] Unknown command: '{cmd_name}'")
    return True

def main():
    load_commands()
    intro()
    while True:
        try:
            command = input("EchoShell > ").strip()
            if not parse_command(command):
                break
        except KeyboardInterrupt:
            print("\nInterrupt detected. Shutting down.")
            break

if __name__ == "__main__":
    main()